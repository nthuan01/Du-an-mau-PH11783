/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dulieu;

/**
 *
 * @author ADMIN
 */
public class khoahoc {
    private String makh,chuyende,thoiluong,hocphi,ngaykhaigiang,nguoitao,ngaytao;

    public khoahoc() {
    }

    public khoahoc(String makh, String chuyende, String thoiluong, String hocphi, String ngaykhaigiang, String nguoitao, String ngaytao) {
        this.makh = makh;
        this.chuyende = chuyende;
        this.thoiluong = thoiluong;
        this.hocphi = hocphi;
        this.ngaykhaigiang = ngaykhaigiang;
        this.nguoitao = nguoitao;
        this.ngaytao = ngaytao;
    }

    public String getMakh() {
        return makh;
    }

    public void setMakh(String makh) {
        this.makh = makh;
    }

    public String getChuyende() {
        return chuyende;
    }

    public void setChuyende(String chuyende) {
        this.chuyende = chuyende;
    }

    public String getThoiluong() {
        return thoiluong;
    }

    public void setThoiluong(String thoiluong) {
        this.thoiluong = thoiluong;
    }

    public String getHocphi() {
        return hocphi;
    }

    public void setHocphi(String hocphi) {
        this.hocphi = hocphi;
    }

    public String getNgaykhaigiang() {
        return ngaykhaigiang;
    }

    public void setNgaykhaigiang(String ngaykhaigiang) {
        this.ngaykhaigiang = ngaykhaigiang;
    }

    public String getNguoitao() {
        return nguoitao;
    }

    public void setNguoitao(String nguoitao) {
        this.nguoitao = nguoitao;
    }

    public String getNgaytao() {
        return ngaytao;
    }

    public void setNgaytao(String ngaytao) {
        this.ngaytao = ngaytao;
    }

    @Override
    public String toString() {
        return "khoahoc{" + "makh=" + makh + ", chuyende=" + chuyende + ", thoiluong=" + thoiluong + ", hocphi=" + hocphi + ", ngaykhaigiang=" + ngaykhaigiang + ", nguoitao=" + nguoitao + ", ngaytao=" + ngaytao + '}';
    }

   
   
}
